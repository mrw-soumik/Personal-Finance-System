/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personalfinancesystem;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class LibrarianModule {
    
    public int checkFileLength(String path) throws IOException {
        
        Scanner readFile = new Scanner(new FileInputStream(path));
        int length = 0;
        while(readFile.hasNextLine())
        {
            readFile.nextLine();
            length++;
        }
        readFile.close();
        return length;
    }
    
    public void modifyBookCategories(){
        try{
            Scanner readFile = new Scanner(new FileInputStream("Categories.txt"));
            int length = checkFileLength("Categories.txt");
            String[] bookcategories = new String[length];
            for(int i=0;i<length;i++)
            {
                System.out.println((i+1)+". "+bookcategories[i]);
            }
            //input user to choose which item to be modified
            //int n = Integer.parseInt(input.nextLine()) - 1;
            /**
             * 
             * input user to type a new name
             * String newName = input.nextLine();
             * bookcategories[i] = newName;
             * //save into file
             */
        }catch(IOException e){
            
        }
    }
    
    public void deleteBookCategories(){
        //display categories
        //ask user input
        //read the file and save into string array
        //string[indextodelete] = null
        //save file
        //loop {
        //if(string[i]!=null)
        //println(string[i])
        //
        //}
    }
}


